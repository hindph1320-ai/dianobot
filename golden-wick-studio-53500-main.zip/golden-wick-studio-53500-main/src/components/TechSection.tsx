import { Card } from '@/components/ui/card';
import jsIcon from '@/assets/js-icon.png';
import reactIcon from '@/assets/react-icon.png';
import htmlIcon from '@/assets/html-icon.png';
import tsIcon from '@/assets/ts-icon.png';

const technologies = [
  {
    name: 'JavaScript',
    icon: jsIcon,
    percentage: 95,
    color: 'from-yellow-400 to-yellow-600'
  },
  {
    name: 'HTML',
    icon: htmlIcon,
    percentage: 100,
    color: 'from-orange-400 to-orange-600'
  },
  {
    name: 'React',
    icon: reactIcon,
    percentage: 90,
    color: 'from-blue-400 to-blue-600'
  },
  {
    name: 'TypeScript',
    icon: tsIcon,
    percentage: 85,
    color: 'from-blue-500 to-blue-700'
  }
];

const TechSection = () => {
  return (
    <section className="py-20 px-6 bg-gradient-to-b from-background to-card">
      <div className="container mx-auto max-w-6xl">
        <div className="text-center mb-16">
          <h2 className="text-4xl font-bold text-secondary glow-text mb-4">
            &lt;programming_languages&gt;
          </h2>
        </div>

        <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-8">
          {technologies.map((tech, index) => (
            <Card 
              key={tech.name}
              className="tech-card p-6 text-center transition-all duration-300 hover:scale-105 border-border bg-card/50 backdrop-blur-sm"
              style={{ animationDelay: `${index * 0.1}s` }}
            >
              {/* Tech Icon */}
              <div className="relative mb-6">
                <img 
                  src={tech.icon} 
                  alt={`${tech.name} icon`}
                  className="w-16 h-16 mx-auto filter drop-shadow-lg animate-float"
                  style={{ animationDelay: `${index * 0.2}s` }}
                />
                {/* Percentage Badge */}
                <div className="absolute -top-2 -right-2 bg-secondary text-accent-foreground text-xs font-bold px-2 py-1 rounded-full">
                  {tech.percentage}%
                </div>
              </div>

              {/* Tech Name */}
              <h3 className="text-xl font-bold text-accent mb-4">{tech.name}</h3>

              {/* Progress Bar */}
              <div className="w-full bg-muted rounded-full h-2 overflow-hidden">
                <div 
                  className="h-full bg-gradient-to-r from-primary to-secondary rounded-full transition-all duration-1000 ease-out"
                  style={{ 
                    width: `${tech.percentage}%`,
                    animationDelay: `${index * 0.2 + 0.5}s`
                  }}
                ></div>
              </div>

              {/* Percentage Text */}
              <div className="mt-2 text-primary font-bold text-lg">
                {tech.percentage}%
              </div>
            </Card>
          ))}
        </div>

        <div className="text-center mt-16">
          <h3 className="text-2xl font-bold text-secondary glow-text">
            &lt;/programming_languages&gt;
          </h3>
        </div>
      </div>
    </section>
  );
};

export default TechSection;