import { Link } from 'react-router-dom';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import heroBackground from '@/assets/hero-bg.jpg';

const HeroSection = () => {
  return (
    <section 
      className="min-h-screen flex items-center justify-center relative overflow-hidden"
      style={{
        backgroundImage: `linear-gradient(rgba(13, 16, 23, 0.8), rgba(13, 16, 23, 0.9)), url(${heroBackground})`,
        backgroundSize: 'cover',
        backgroundPosition: 'center',
        backgroundAttachment: 'fixed'
      }}
    >
      {/* Matrix Binary Background */}
      <div className="absolute inset-0 matrix-binary text-xs leading-none">
        {Array.from({ length: 100 }, (_, i) => (
          <div key={i} className="absolute" style={{
            left: `${Math.random() * 100}%`,
            top: `${Math.random() * 100}%`,
            animationDelay: `${Math.random() * 5}s`
          }}>
            {Math.random() > 0.5 ? '1' : '0'}
          </div>
        ))}
      </div>

      <div className="container mx-auto px-6 text-center relative z-10">
        {/* Main Title */}
        <h1 className="text-6xl md:text-8xl font-bold mb-6 glow-text animate-fade-in">
          <span className="bg-gradient-to-r from-primary to-secondary bg-clip-text text-transparent">
            DEVELOPER
          </span>
        </h1>

        {/* Subtitle with typing effect */}
        <div className="text-xl md:text-2xl text-muted-foreground mb-8 font-mono">
          <span className="typing">&lt;Programmer From Iraq /&gt;</span>
        </div>

        {/* Badges */}
        <div className="flex flex-wrap justify-center gap-4 mb-12">
          <Badge variant="outline" className="px-6 py-2 text-primary border-primary glow-text">
            🇮🇶 Iraq
          </Badge>
          <Badge variant="secondary" className="px-6 py-2 text-accent-foreground bg-secondary">
            💻 Developer
          </Badge>
        </div>

        {/* CTA Button */}
        <Link to="/portfolio">
          <Button 
            size="lg" 
            className="px-12 py-6 text-lg font-semibold bg-gradient-to-r from-primary to-primary-foreground hover:from-primary-glow hover:to-primary animate-glow-pulse transition-all duration-300"
          >
            🚀 ENTER 🔥
          </Button>
        </Link>

        {/* Scroll indicator */}
        <div className="absolute bottom-8 left-1/2 transform -translate-x-1/2 animate-bounce">
          <div className="w-6 h-10 border-2 border-primary rounded-full flex justify-center">
            <div className="w-1 h-3 bg-primary rounded-full mt-2 animate-pulse"></div>
          </div>
        </div>
      </div>
    </section>
  );
};

export default HeroSection;