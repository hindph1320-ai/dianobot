import { useEffect, useState } from 'react';
import jsIcon from '@/assets/js-icon.png';
import reactIcon from '@/assets/react-icon.png';
import htmlIcon from '@/assets/html-icon.png';
import tsIcon from '@/assets/ts-icon.png';

interface FloatingIcon {
  id: number;
  src: string;
  x: number;
  y: number;
  size: number;
  delay: number;
}

const FloatingIcons = () => {
  const [icons, setIcons] = useState<FloatingIcon[]>([]);

  useEffect(() => {
    const iconSources = [jsIcon, reactIcon, htmlIcon, tsIcon];
    const newIcons: FloatingIcon[] = [];

    // Create 12 floating icons
    for (let i = 0; i < 12; i++) {
      newIcons.push({
        id: i,
        src: iconSources[i % iconSources.length],
        x: Math.random() * 100,
        y: Math.random() * 100,
        size: 20 + Math.random() * 20,
        delay: Math.random() * 6
      });
    }

    setIcons(newIcons);
  }, []);

  return (
    <div className="fixed inset-0 pointer-events-none overflow-hidden" style={{ zIndex: 1 }}>
      {icons.map((icon) => (
        <img
          key={icon.id}
          src={icon.src}
          alt="Tech icon"
          className="floating-icon"
          style={{
            left: `${icon.x}%`,
            top: `${icon.y}%`,
            width: `${icon.size}px`,
            height: `${icon.size}px`,
            animationDelay: `${icon.delay}s`,
            opacity: 0.4,
          }}
        />
      ))}
    </div>
  );
};

export default FloatingIcons;