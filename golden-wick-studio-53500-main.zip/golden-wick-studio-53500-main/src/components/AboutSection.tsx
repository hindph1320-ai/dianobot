import { Card } from '@/components/ui/card';

const AboutSection = () => {
  return (
    <section className="py-20 px-6">
      <div className="container mx-auto max-w-6xl">
        <div className="grid md:grid-cols-2 gap-8">
          {/* About Me Code Block */}
          <Card className="code-block p-8 animate-slide-up">
            <div className="mb-4">
              <h2 className="text-2xl font-bold text-secondary glow-text">&lt;about_me&gt;</h2>
            </div>
            
            <div className="font-mono text-sm leading-relaxed">
              <div className="text-primary">const</div>
              <div className="text-foreground ml-4">programmer = {`{`}</div>
              <div className="ml-8 space-y-2">
                <div>
                  <span className="text-secondary">name:</span>
                  <span className="text-accent"> 'Ahmed'</span>,
                </div>
                <div>
                  <span className="text-secondary">location:</span>
                  <span className="text-accent"> 'Iraq 🇮🇶'</span>,
                </div>
                <div>
                  <span className="text-secondary">passion:</span>
                  <span className="text-accent"> 'Coding & Creating'</span>,
                </div>
                <div>
                  <span className="text-secondary">mission:</span>
                  <span className="text-accent"> 'Building Amazing Software'</span>
                </div>
              </div>
              <div className="text-foreground">{`}`}</div>
            </div>

            <div className="mt-6">
              <h3 className="text-lg font-bold text-secondary">&lt;/about_me&gt;</h3>
            </div>
          </Card>

          {/* Skills Code Block */}
          <Card className="code-block p-8 animate-slide-up" style={{ animationDelay: '0.2s' }}>
            <div className="mb-4">
              <h2 className="text-2xl font-bold text-secondary glow-text">&lt;skills&gt;</h2>
            </div>
            
            <div className="space-y-6">
              {/* JavaScript */}
              <div>
                <div className="flex justify-between mb-2">
                  <span className="text-accent font-semibold">JavaScript</span>
                  <span className="text-primary">95%</span>
                </div>
                <div className="w-full bg-muted rounded-full h-3 overflow-hidden">
                  <div 
                    className="progress-bar h-full rounded-full" 
                    style={{ width: '95%', animationDelay: '0.5s' }}
                  ></div>
                </div>
              </div>

              {/* React */}
              <div>
                <div className="flex justify-between mb-2">
                  <span className="text-accent font-semibold">React</span>
                  <span className="text-primary">90%</span>
                </div>
                <div className="w-full bg-muted rounded-full h-3 overflow-hidden">
                  <div 
                    className="progress-bar h-full rounded-full" 
                    style={{ width: '90%', animationDelay: '0.7s' }}
                  ></div>
                </div>
              </div>

              {/* TypeScript */}
              <div>
                <div className="flex justify-between mb-2">
                  <span className="text-accent font-semibold">TypeScript</span>
                  <span className="text-primary">85%</span>
                </div>
                <div className="w-full bg-muted rounded-full h-3 overflow-hidden">
                  <div 
                    className="progress-bar h-full rounded-full" 
                    style={{ width: '85%', animationDelay: '0.9s' }}
                  ></div>
                </div>
              </div>

              {/* HTML/CSS */}
              <div>
                <div className="flex justify-between mb-2">
                  <span className="text-accent font-semibold">HTML/CSS</span>
                  <span className="text-primary">100%</span>
                </div>
                <div className="w-full bg-muted rounded-full h-3 overflow-hidden">
                  <div 
                    className="progress-bar h-full rounded-full" 
                    style={{ width: '100%', animationDelay: '1.1s' }}
                  ></div>
                </div>
              </div>
            </div>

            <div className="mt-6 text-matrix-code">
              <p>// Loading more skills...</p>
              <p>// Stay tuned for updates!</p>
            </div>

            <div className="mt-4">
              <h3 className="text-lg font-bold text-secondary">&lt;/skills&gt;</h3>
            </div>
          </Card>
        </div>
      </div>
    </section>
  );
};

export default AboutSection;