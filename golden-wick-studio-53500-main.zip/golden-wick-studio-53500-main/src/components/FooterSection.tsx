import { Link } from 'react-router-dom';
import { Button } from '@/components/ui/button';
import { SOCIAL_LINKS, STUDIO_INFO } from '@/constants/socialLinks';

const FooterSection = () => {
  return (
    <footer className="py-20 px-6 bg-card border-t border-border">
      <div className="container mx-auto max-w-4xl text-center">
        {/* Studio Name */}
        <div className="mb-8">
          <h2 className="text-4xl md:text-6xl font-bold mb-4">
            <span className="text-secondary glow-text">WICK STUDIO</span>
          </h2>
          <div className="h-1 w-32 bg-gradient-to-r from-primary to-secondary mx-auto rounded-full"></div>
        </div>

        {/* Call to Action */}
        <div className="mb-12">
          <p className="text-xl text-muted-foreground mb-8 font-mono">
            Ready to build something amazing?
          </p>
          
          <Link to="/portfolio">
            <Button 
              size="lg"
              className="px-12 py-6 text-lg font-bold bg-gradient-to-r from-primary via-secondary to-primary hover:scale-105 transition-all duration-300 animate-glow-pulse"
            >
              🚀 ENTER 🔥
            </Button>
          </Link>
        </div>

        {/* Copyright */}
        <div className="border-t border-border pt-8">
          <p className="text-muted-foreground font-mono">
            © {STUDIO_INFO.year} {STUDIO_INFO.name}. {STUDIO_INFO.description}
          </p>
          <div className="flex justify-center space-x-4 mt-4 text-sm text-primary">
            <a href={SOCIAL_LINKS.github} target="_blank" rel="noopener noreferrer" className="hover:text-secondary cursor-pointer transition-colors">GitHub</a>
            <a href={SOCIAL_LINKS.discord} target="_blank" rel="noopener noreferrer" className="hover:text-secondary cursor-pointer transition-colors">Discord</a>
          </div>
        </div>

        {/* Matrix Code Footer */}
        <div className="mt-8 text-xs text-primary/30 font-mono">
          {Array.from({ length: 50 }, (_, i) => (
            <span key={i} className="inline-block mx-1 animate-pulse" style={{ animationDelay: `${i * 0.1}s` }}>
              {Math.random() > 0.5 ? '1' : '0'}
            </span>
          ))}
        </div>
      </div>
    </footer>
  );
};

export default FooterSection;