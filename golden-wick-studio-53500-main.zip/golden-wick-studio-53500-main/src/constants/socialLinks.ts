// Social media and contact links
// يمكنك تعديل الروابط من هنا بسهولة
export const SOCIAL_LINKS = {
  github: 'https://github.com/wickstudio',
  discord: 'https://discord.gg/wicks',
  email: 'contact@wickstudio.com', // عدل الإيميل هنا
  phone: '+1234567890', // عدل رقم الهاتف هنا
};

export const STUDIO_INFO = {
  name: 'WICK STUDIO',
  description: 'Professional Web Development',
  year: '2024',
};
