import { Button } from '@/components/ui/button';
import { Card } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Link } from 'react-router-dom';
import { ArrowLeft, Github, ExternalLink, Mail, MessageCircle } from 'lucide-react';
import { SOCIAL_LINKS, STUDIO_INFO } from '@/constants/socialLinks';
import jsIcon from '@/assets/js-icon.png';
import reactIcon from '@/assets/react-icon.png';
import htmlIcon from '@/assets/html-icon.png';
import tsIcon from '@/assets/ts-icon.png';

const projects = [
  {
    id: 1,
    title: "E-Commerce Platform",
    description: "Full-stack e-commerce solution with React and Node.js",
    tech: ["React", "Node.js", "MongoDB", "Express"],
    status: "Completed"
  },
  {
    id: 2,
    title: "Task Management App",
    description: "Modern task management application with real-time updates",
    tech: ["TypeScript", "React", "Firebase", "Tailwind"],
    status: "In Progress"
  },
  {
    id: 3,
    title: "Weather Dashboard",
    description: "Beautiful weather dashboard with location-based forecasts",
    tech: ["JavaScript", "React", "API Integration", "Charts"],
    status: "Completed"
  }
];

const Portfolio = () => {
  return (
    <div className="min-h-screen bg-background">
      {/* Header */}
      <header className="bg-card border-b border-border">
        <div className="container mx-auto px-6 py-4">
          <div className="flex justify-between items-center">
            <Link to="/">
              <Button variant="outline" className="flex items-center gap-2">
                <ArrowLeft className="w-4 h-4" />
                Back to Home
              </Button>
            </Link>
            <h1 className="text-2xl font-bold text-secondary">{STUDIO_INFO.name}</h1>
          </div>
        </div>
      </header>

      <main className="py-12">
        <div className="container mx-auto px-6 max-w-6xl">
          {/* Profile Section */}
          <section className="text-center mb-16">
            <h1 className="text-5xl font-bold mb-4">
              <span className="bg-gradient-to-r from-primary to-secondary bg-clip-text text-transparent">
                Developer Portfolio
              </span>
            </h1>
            <p className="text-xl text-muted-foreground mb-8">
              Full-Stack Developer specializing in modern web technologies
            </p>
            
            <div className="flex justify-center gap-4 mb-8">
              <a href={`mailto:${SOCIAL_LINKS.email}`}>
                <Button className="flex items-center gap-2">
                  <Mail className="w-4 h-4" />
                  Contact Me
                </Button>
              </a>
              <a href={SOCIAL_LINKS.github} target="_blank" rel="noopener noreferrer">
                <Button variant="outline" className="flex items-center gap-2">
                  <Github className="w-4 h-4" />
                  GitHub
                </Button>
              </a>
            </div>
          </section>

          {/* Skills Grid */}
          <section className="mb-16">
            <h2 className="text-3xl font-bold text-center mb-12 text-secondary">
              Technical Skills
            </h2>
            <div className="grid md:grid-cols-4 gap-6">
              {[
                { name: 'JavaScript', icon: jsIcon, level: 'Expert' },
                { name: 'React', icon: reactIcon, level: 'Expert' },
                { name: 'TypeScript', icon: tsIcon, level: 'Advanced' },
                { name: 'HTML/CSS', icon: htmlIcon, level: 'Expert' }
              ].map((skill) => (
                <Card key={skill.name} className="p-6 text-center hover:shadow-lg transition-all">
                  <img src={skill.icon} alt={skill.name} className="w-12 h-12 mx-auto mb-4" />
                  <h3 className="font-semibold text-accent mb-2">{skill.name}</h3>
                  <Badge variant="secondary">{skill.level}</Badge>
                </Card>
              ))}
            </div>
          </section>

          {/* Projects Section */}
          <section className="mb-16">
            <h2 className="text-3xl font-bold text-center mb-12 text-secondary">
              Featured Projects
            </h2>
            <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-8">
              {projects.map((project) => (
                <Card key={project.id} className="p-6 hover:shadow-lg transition-all">
                  <div className="flex justify-between items-start mb-4">
                    <h3 className="text-xl font-bold text-accent">{project.title}</h3>
                    <ExternalLink className="w-5 h-5 text-primary cursor-pointer hover:text-secondary" />
                  </div>
                  <p className="text-muted-foreground mb-4">{project.description}</p>
                  <div className="flex flex-wrap gap-2 mb-4">
                    {project.tech.map((tech) => (
                      <Badge key={tech} variant="outline" className="text-xs">
                        {tech}
                      </Badge>
                    ))}
                  </div>
                  <Badge 
                    variant={project.status === 'Completed' ? 'default' : 'secondary'}
                    className="w-full justify-center"
                  >
                    {project.status}
                  </Badge>
                </Card>
              ))}
            </div>
          </section>

          {/* Contact Section */}
          <section className="text-center">
            <Card className="p-12 bg-gradient-to-r from-card to-muted">
              <h2 className="text-3xl font-bold mb-4 text-secondary">
                Let's Work Together
              </h2>
              <p className="text-lg text-muted-foreground mb-8 max-w-2xl mx-auto">
                Ready to bring your ideas to life? Let's discuss your next project.
              </p>
              <div className="flex justify-center gap-4">
                <a href={`mailto:${SOCIAL_LINKS.email}`}>
                  <Button size="lg" className="flex items-center gap-2">
                    <Mail className="w-5 h-5" />
                    Get In Touch
                  </Button>
                </a>
                <a href={SOCIAL_LINKS.discord} target="_blank" rel="noopener noreferrer">
                  <Button size="lg" variant="outline" className="flex items-center gap-2">
                    <MessageCircle className="w-5 h-5" />
                    Discord
                  </Button>
                </a>
              </div>
            </Card>
          </section>
        </div>
      </main>

      {/* Footer */}
      <footer className="bg-card border-t border-border py-8">
        <div className="container mx-auto px-6 text-center">
          <p className="text-muted-foreground">
            © {STUDIO_INFO.year} {STUDIO_INFO.name}. All rights reserved.
          </p>
        </div>
      </footer>
    </div>
  );
};

export default Portfolio;