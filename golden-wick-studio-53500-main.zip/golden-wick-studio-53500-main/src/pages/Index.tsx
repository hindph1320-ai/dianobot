import MatrixRain from '@/components/MatrixRain';
import FloatingIcons from '@/components/FloatingIcons';
import HeroSection from '@/components/HeroSection';
import AboutSection from '@/components/AboutSection';
import TechSection from '@/components/TechSection';
import FooterSection from '@/components/FooterSection';

const Index = () => {
  return (
    <div className="min-h-screen bg-background relative overflow-x-hidden">
      {/* Background Effects */}
      <MatrixRain />
      <FloatingIcons />
      
      {/* Main Content */}
      <main className="relative z-10">
        <HeroSection />
        <AboutSection />
        <TechSection />
        <FooterSection />
      </main>
    </div>
  );
};

export default Index;